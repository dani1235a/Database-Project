CREATE proc spHelloPerson
as
select * from Person.person
where Title = 'Miss'
GO
