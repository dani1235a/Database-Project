create function getDiff(@d date)
returns int
Begin
	return (Datediff(Day, @d, GetDate()))
end
GO
