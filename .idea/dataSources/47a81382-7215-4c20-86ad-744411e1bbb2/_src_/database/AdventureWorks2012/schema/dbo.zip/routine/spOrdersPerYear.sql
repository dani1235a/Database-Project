create proc spOrdersPerYear
	@date date,
	@ProductID int,
	@orders int output
as 
	select @orders = count(*)
	from Sales.SalesOrderDetail as SOD
	inner join Sales.SalesOrderHeader as SOH
	on SOD.SalesOrderID = SOH.SalesOrderID
	where OrderDate = datepart(yyyy, @date)
GO
