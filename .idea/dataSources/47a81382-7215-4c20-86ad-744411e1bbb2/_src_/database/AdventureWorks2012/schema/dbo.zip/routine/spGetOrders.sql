CREATE proc spGetOrders
	@Fname varchar(20),
	@Lname varchar(20),
	@date date = null,
	@orders int OUTPUT
as
	if @date is null
		select @orders = count(*)
		from person.person as P
		inner join Sales.SalesOrderHeader as SOH
		on SOH.CustomerID = P.BusinessEntityID
		where FirstName = @Fname and LastName = @Lname

	else 
				select @orders = count(*)
		from person.person as P
		inner join Sales.SalesOrderHeader as SOH
		on SOH.CustomerID = P.BusinessEntityID
		where FirstName = @Fname and LastName = @Lname and OrderDate = @date
GO
