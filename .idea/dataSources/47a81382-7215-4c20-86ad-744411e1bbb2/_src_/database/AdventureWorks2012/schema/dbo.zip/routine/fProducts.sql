create function fProducts()
returns Table
	return (select ProductID, Name
	from Production.Product);
GO
