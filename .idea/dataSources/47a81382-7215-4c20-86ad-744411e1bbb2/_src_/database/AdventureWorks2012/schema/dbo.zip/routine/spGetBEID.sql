create proc spGetBEID
	@Fname varchar(20),
	@Lname varchar(20),
	@BEID int OUTPUT
as 
	select @BEID = BusinessEntityID
	from Person.person
	where FirstName = @Fname and LastName = @Lname
GO
