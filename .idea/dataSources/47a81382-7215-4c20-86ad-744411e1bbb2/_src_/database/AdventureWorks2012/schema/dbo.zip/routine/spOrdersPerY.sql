create proc spOrdersPerY
	@date int,
	@ProductID int,
	@orders int output
as 
	select @orders = count(*)
	from Sales.SalesOrderDetail as SOD
	inner join Sales.SalesOrderHeader as SOH
	on SOD.SalesOrderID = SOH.SalesOrderID
	where datepart(yyyy, OrderDate) = @date and ProductID = @ProductID
GO
