/**
 * This class takes information to build a query.
 */

public class Query {

    /**
     * Constructor. Takes no Parameters.
     */
    public Query() {

    }

    /**
     * Returns the search query in String form.
     * @return
     */
    public String getQuery(){
        return null;
    }
}
